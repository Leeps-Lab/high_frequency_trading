window.WCT = {
  environmentScripts: [
    'stacky/lib/parsing.js',
    'stacky/lib/formatting.js',
    'stacky/lib/normalization.js',
    'mocha/mocha.js',
    'chai/chai.js',
    '@polymer/sinonjs/sinon.js',
    // 'accessibility-developer-tools/dist/js/axs_testing.js',
    // '@polymer/test-fixture/test-fixture.js'
  ],
  environmentImports: [],
  // verbose: true
}