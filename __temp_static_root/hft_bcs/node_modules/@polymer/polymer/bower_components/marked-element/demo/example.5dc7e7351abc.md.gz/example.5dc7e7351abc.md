## Markdown Renderer

Example:

```html
<paper-toolbar>
  <paper-icon-button icon="menu"></paper-icon-button>
  <div class="title">Title</div>
  <paper-icon-button icon="more"></paper-icon-button>
</paper-toolbar>
```

_Nifty_ features.
